<template>
  <div>
    我是js页面，js有很多的框架，vue react ng
  </div>
</template>
