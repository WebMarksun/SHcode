<template>
  <div>
    我是about页面
  </div>
</template>
<script>
  export default {
    
    mounted() {
      console.log('about.vue渲染完成')
    },
  }
</script>
