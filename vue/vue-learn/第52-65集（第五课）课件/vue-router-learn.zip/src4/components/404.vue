<template>
  <div>
    你访问的页面给外星人带走了。。。。
  </div>
</template>
