import mutations from './mutations'
var firstPage = {
  namespaced: true,
  state:{
    f1:1,
    f2:2
  },
  mutations: mutations,
}

export default firstPage;