export default {
  updateF1(state,payload) {
    state.f1 = 100000
  },
}