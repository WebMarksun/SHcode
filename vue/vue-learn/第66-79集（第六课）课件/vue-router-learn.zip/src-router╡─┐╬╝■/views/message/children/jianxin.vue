<template>
  <div>
    这是简信页面
  </div>
</template>
