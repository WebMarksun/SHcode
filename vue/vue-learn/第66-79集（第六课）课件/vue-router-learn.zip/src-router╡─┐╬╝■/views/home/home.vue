<template>
  <!--发现页面-->
  <div>
    <h2>发现页面</h2>
  </div>
</template>
