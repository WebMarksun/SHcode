<template>
  <div id="app">
    <shopCar></shopCar>
  </div>
</template>

<script>
// @ 代表src目录
import shopCar from '@/views/shopCar'
export default {
  name: 'App',
  components: {
    shopCar
  }
}
</script>

<style>

</style>
