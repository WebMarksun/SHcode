export default [
  {
    id:123,
    img_url: 'https://i1.mifile.cn/a1/T1SkV_BCd_1RXrhCrK!80x80.jpg',
    title: '小米胶囊耳机 黑色',
    price: 59,
    count: 2,
    max_count: 5
  },
  {
    id:456,
    img_url: 'https://i1.mifile.cn/a1/pms_1498624482.88089389!80x80.jpg',
    title: '米家激光投影电视 150英寸 白色',
    price: 9999,
    count: 2,
    max_count: 5
  },
  {
    id:789,
    img_url: 'https://i1.mifile.cn/a1/pms_1505208926.31382783!80x80.jpg',
    title: '米动手表青春版 卡其绿',
    price: 3999,
    count: 2,
    max_count: 5
  },
  
]