// export 一个一个导出 用import用结构赋值 import {add,miaov} from '' 
// import * as object from ''
export function add() {
  console.log('相加')
}

export function miaov() {
  console.log('miaov')
}

// export default   默认导出 import 变量 from ''

// 默认导出
/*export default {
  add,
  miaov
}*/