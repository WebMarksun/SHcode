<template>
  <header class="header" >
      <h1>todos</h1>
      <input class="new-todo" placeholder="请输入内容" />
  </header>
</template>
