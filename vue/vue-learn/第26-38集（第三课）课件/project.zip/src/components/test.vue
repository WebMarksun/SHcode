<template>
  <div>
    hello,我是测试组件,{{title}}
    <p>渲染状态：{{m}}</p>
    <button @click="changeStateN">改变状态</button>
  </div>
</template>
<script>
// 导出的对象就是选项对象
  export default {
    props: ['title'],
    data(){
      return {
        m: this.$store.state.n
      }
    },
    methods:{
      changeStateN(){
        // 改变状态
        // 不能直接改：this.$store.state.n = 1000000;
        // 提交mutation
        this.$store.commit('changeN')
      }
    }
  }
</script>
