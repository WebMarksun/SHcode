// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import Vuex from 'vuex'

Vue.use(Vuex); // 作为插件
// 创建容器
let store = new Vuex.Store({
  state: {
    n:100
  },
  mutations:{  // 每一条称之为mutation，用来改变state
    changeN(state){
      var m = state.n;
      state.n = ++m;
    }
  }
})

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  store: store, // 注入到根实例中，每个组件都可以使用这个store
  components: { App },
  template: '<App/>'
})
