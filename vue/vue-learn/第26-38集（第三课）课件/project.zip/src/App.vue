<template>
  <div id="app">
    <h1>测试使用组件</h1>
    <test title="娱乐"></test>
    <p>使用vuex中的数据: {{$store.state.n}}</p>
  </div>
</template>

<script>
import Test from '@/components/test';

// 引入组件 注册组件 模板中使用组件
export default {
  name: 'App',
  components:{
    //abc: Test
    Test
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
