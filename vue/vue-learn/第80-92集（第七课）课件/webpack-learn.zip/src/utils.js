import 'vue'
export function type(a) {
  return typeof a;
}