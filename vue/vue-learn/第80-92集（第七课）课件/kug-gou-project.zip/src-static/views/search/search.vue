<template>
  <div>
    这是搜索页面
  </div>
</template>
